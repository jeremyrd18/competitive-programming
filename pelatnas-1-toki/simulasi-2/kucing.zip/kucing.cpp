#include "kucing.h"

long long latihanKucing(int N, std::vector<int> P, std::vector<int> A, std::vector<int> B) {
  return 0;
}