#include "root.h"

int findRoot(int H) {
  return 1;
}